#!/usr/bin/env bash
set -e
echo "🔵 Building EAS preview build…"
eas build --platform android --profile preview --non-interactive --local

OUTPUT_JSON=".eas/local-build/builds/android*/metadata.json"

if [ ! -f $OUTPUT_JSON ]; then
  echo "❌ No metadata.json found. Build might have failed."
  exit 1
fi

URL=$(jq -r '.artifactPath' $OUTPUT_JSON)

if [ -z "$URL" ]; then
  echo "❌ No artifact URL found."
  exit 1
fi

echo "🔵 Generating QR code…"
qrencode -o preview-qr.png "$URL"

echo "🎉 Preview QR generated at preview-qr.png"
