    # Running Route App

    Expo React Native starter that generates loop running routes that start and end at the same point, renders them on a map, and exports GPX files.

    ## Features
    - Map rendering with react-native-maps
    - Generate looped routes by distance and waypoint count (3–6)
    - Preview multiple route options and export to GPX
    - Expo-ready; instructions for building with EAS

    ## Quickstart
    1. Install dependencies: `npm install` or `yarn install` (use `expo-cli` or `npx expo`)
2. Run: `expo start` and open on a device or simulator

### Notes
- `react-native-maps` may require native configuration on bare/react-native projects. For Expo managed workflow use `expo install react-native-maps`.
- To enable accurate snapping to roads or turn-by-turn routing, integrate Mapbox/Google Directions (requires API key).

## CI (GitHub Actions)
This repo includes a sample CI to run `npm test` and `expo prebuild` in GitHub Actions. See `.github/workflows/ci.yml`.
