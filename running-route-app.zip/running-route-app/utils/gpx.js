// Build a simple GPX string from coordinates
import { create } from 'xmlbuilder';

export function gpxFromCoordinates(coords, { name = 'route' } = {}) {
  // coords: array of {latitude, longitude}
  const doc = create('gpx', { version: '1.0', encoding: 'UTF-8' });
  doc.att('version', '1.1');
  doc.att('creator', 'Running Route App');
  doc.att('xmlns', 'http://www.topografix.com/GPX/1/1');

  const trk = doc.ele('trk');
  trk.ele('name', {}, name);
  const seg = trk.ele('trkseg');

  coords.forEach(c => {
    seg.ele('trkpt', { lat: c.latitude.toString(), lon: c.longitude.toString() });
  });

  return doc.end({ pretty: true });
}
