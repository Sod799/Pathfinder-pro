// Simple generator that creates loop routes by placing waypoints on a circle around the start
// so that the polygon perimeter approximates the requested distance. Returns an array of route options.

import haversine from 'haversine-distance';

function metersBetween(a, b) {
  return haversine(a, b);
}

function pointOnCircle(center, radiusMeters, angleRad) {
  const earthRadius = 6378137.0; // m
  const dx = radiusMeters * Math.cos(angleRad);
  const dy = radiusMeters * Math.sin(angleRad);

  const lat = center.latitude + (dy / earthRadius) * (180 / Math.PI);
  const lon = center.longitude + (dx / (earthRadius * Math.cos(center.latitude * Math.PI / 180))) * (180 / Math.PI);
  return { latitude: lat, longitude: lon };
}

export function generateLoopRouteOptions({ start, distanceKm = 5, waypointCount = 4, optionsCount = 3 }) {
  const targetMeters = distanceKm * 1000;
  const routes = [];

  // circle radius that gives approximate circumference = targetMeters
  const baseRadius = targetMeters / (2 * Math.PI);

  for (let opt = 0; opt < optionsCount; opt++) {
    // stagger radius and phase for variety
    const radius = baseRadius * (0.8 + Math.random() * 0.6); // ±20% to +60%
    const phase = Math.random() * Math.PI * 2;

    const coords = [];
    for (let i = 0; i < waypointCount; i++) {
      const angle = phase + (i / waypointCount) * (2 * Math.PI);
      // apply small radial noise
      const r = radius * (0.9 + Math.random() * 0.2);
      coords.push(pointOnCircle(start, r, angle));
    }

    // compute actual perimeter
    const fullCoords = [start, ...coords, start];
    let dist = 0;
    for (let i = 0; i < fullCoords.length - 1; i++) {
      dist += metersBetween(fullCoords[i], fullCoords[i + 1]);
    }

    routes.push({ id: opt, coords, distanceKm: dist / 1000 });
  }

  // sort by closeness to target
  routes.sort((a, b) => Math.abs(a.distanceKm - distanceKm) - Math.abs(b.distanceKm - distanceKm));
  return routes;
}
