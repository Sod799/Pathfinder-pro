import React, { useEffect, useState, useRef } from 'react';
import { StyleSheet, View, Text, TextInput, Button, Alert, TouchableOpacity, ActivityIndicator, Platform } from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import * as Location from 'expo-location';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import haversine from 'haversine-distance';
import { generateLoopRouteOptions } from './utils/routeGen';
import { gpxFromCoordinates } from './utils/gpx';
import RouteCard from './components/RouteCard';

export default function App() {
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [distanceKm, setDistanceKm] = useState('5');
  const [waypoints, setWaypoints] = useState('4');
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(false);
  const mapRef = useRef(null);
  const [selectedRouteIndex, setSelectedRouteIndex] = useState(null);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
        return;
      }

      let loc = await Location.getCurrentPositionAsync({});
      setLocation({ latitude: loc.coords.latitude, longitude: loc.coords.longitude, latitudeDelta: 0.01, longitudeDelta: 0.01 });
    })();
  }, []);

  const generateRoutes = async () => {
    if (!location) return Alert.alert('Location unknown', 'Allow location access and try again');
    const km = parseFloat(distanceKm);
    const n = Math.max(3, Math.min(6, parseInt(waypoints, 10) || 4));
    if (!km || km <= 0) return Alert.alert('Invalid distance', 'Enter a positive km value');

    setLoading(true);
    try {
      // Generate 3 route options
      const options = generateLoopRouteOptions({ start: location, distanceKm: km, waypointCount: n, optionsCount: 3 });
      setRoutes(options);
      setSelectedRouteIndex(0);

      // Fit map to route
      setTimeout(() => {
        if (mapRef.current && options[0]) {
          const coords = [location, ...options[0].coords, location].map(p => ({ latitude: p.latitude, longitude: p.longitude }));
          mapRef.current.fitToCoordinates(coords, { edgePadding: { top: 60, right: 40, bottom: 60, left: 40 }, animated: true });
        }
      }, 500);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const exportGPX = async (route) => {
    if (!route) return;
    try {
      const coords = [location, ...route.coords, location];
      const gpxText = gpxFromCoordinates(coords, { name: `run_${Math.round(route.distanceKm * 1000)}m` });

      const filename = `route_${Date.now()}.gpx`;
      const path = FileSystem.documentDirectory + filename;
      await FileSystem.writeAsStringAsync(path, gpxText, { encoding: FileSystem.EncodingType.UTF8 });

      if (Platform.OS === 'web') {
        Alert.alert('Saved', 'GPX saved to browser downloads (platform-specific)');
      } else {
        await Sharing.shareAsync(path);
      }
    } catch (e) {
      Alert.alert('Export failed', e.message);
    }
  };

  if (errorMsg) {
    return (
      <View style={styles.center}>
        <Text>{errorMsg}</Text>
      </View>
    );
  }

  if (!location) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
        <Text style={{ marginTop: 10 }}>Acquiring location…</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <MapView ref={mapRef} style={styles.map} initialRegion={location} showsUserLocation>
        <Marker coordinate={location} title="Start/End" description="Your start location" />

        {routes[selectedRouteIndex] && (
          <>
            <Polyline coordinates={[location, ...routes[selectedRouteIndex].coords, location]} strokeWidth={4} />
            {routes[selectedRouteIndex].coords.map((c, i) => (
              <Marker key={i} coordinate={c} pinColor={i === 0 ? 'green' : 'orange'} />
            ))}
          </>
        )}
      </MapView>

      <View style={styles.controls}>
        <Text style={styles.title}>Running Route Generator</Text>

        <View style={styles.row}>
          <TextInput style={styles.input} keyboardType="numeric" value={distanceKm} onChangeText={setDistanceKm} placeholder="Distance km" />
          <TextInput style={[styles.input, { marginLeft: 10 }]} keyboardType="numeric" value={waypoints} onChangeText={setWaypoints} placeholder="Waypoints (3-6)" />
          <Button title="Generate" onPress={generateRoutes} />
        </View>

        {loading && <ActivityIndicator style={{ marginTop: 8 }} />}

        <View style={{ height: 160 }}>
          {routes.map((r, idx) => (
            <TouchableOpacity key={idx} onPress={() => setSelectedRouteIndex(idx)}>
              <RouteCard
                title={`Option ${idx + 1}`}
                distanceKm={r.distanceKm}
                highlighted={selectedRouteIndex === idx}
                onExport={() => exportGPX(r)}
              />
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  map: { flex: 1 },
  controls: { position: 'absolute', left: 12, right: 12, top: 14, backgroundColor: 'rgba(255,255,255,0.95)', borderRadius: 12, padding: 12, elevation: 6 },
  title: { fontSize: 18, fontWeight: '700', marginBottom: 8 },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  input: { flex: 1, borderWidth: 1, borderColor: '#eee', padding: 8, borderRadius: 8, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' }
});
