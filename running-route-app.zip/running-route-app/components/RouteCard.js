import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

export default function RouteCard({ title, distanceKm, highlighted, onExport }) {
  return (
    <View style={[styles.card, highlighted && styles.highlight]}>
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.distance}>{distanceKm.toFixed(2)} km</Text>
      </View>

      <TouchableOpacity onPress={onExport} style={styles.exportBtn}>
        <Text style={{ color: 'white' }}>GPX</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: 'row', alignItems: 'center', padding: 10, marginVertical: 6, backgroundColor: '#fff', borderRadius: 8, elevation: 2 },
  title: { fontWeight: '700' },
  distance: { color: '#333' },
  exportBtn: { backgroundColor: '#007bff', paddingVertical: 6, paddingHorizontal: 12, borderRadius: 6 },
  highlight: { borderColor: '#007bff', borderWidth: 2 }
});
