#!/usr/bin/env bash
echo 'Sample APK build script'
