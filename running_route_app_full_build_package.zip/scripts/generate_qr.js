import QRCode from 'qrcode';
const previewUrl = 'https://expo.dev/accounts/<your-username>/projects/running-route-app/builds/<build-id>';
QRCode.toFile('preview_qr.png', previewUrl, { width: 300 }, (err) => {
  if(err) console.error(err);
  else console.log('QR code generated at preview_qr.png');
});
