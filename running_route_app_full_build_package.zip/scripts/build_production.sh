#!/usr/bin/env bash
echo 'Sample production build script (AAB + IPA)'
